import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { IUser } from './user';

@Injectable({
  providedIn: 'root'
})
export class IssueService {

  uri = 'http://localhost:3000/api/user';

  constructor(private http:HttpClient) { }

  getdata():Observable<IUser[]>{
    return this.http.get<IUser[]>(`${this.uri}/listall`);
  }

  //below method add the record in database, it creates the object rec, 
  //and fill the rec object with values passed by addRecord() method from ts file.
  //we calling post and passing rec object 
  addRec(id,firstName,lastName)
  {
    const rec = {
      id:id,
      firstName:firstName,
      lastName:lastName
    }
    return this.http.post(`${this.uri}/insertrec`, rec);
  }
  //below method takes the id as parameter which is passed by the deleteRecord()
  //method from ts file
  deleteRec(id)
  {
    return this.http.delete(`${this.uri}/del/${id}`);
  }

  updateRec(id,firstName,lastName)
  {
    const rec = {
      id:id,
      firstName:firstName,
      lastName:lastName
    }
    return this.http.post(`${this.uri}/change/${id}`, rec); 
  }
}
