const express = require('express')
const app = express();
const cors = require('cors')


const connectDB = require('./DB/connection');

connectDB()

app.use(cors());
app.use(express.json({ extended: false}));
app.use('/api/user', require('./Api/User'));


const Port = process.env.Port || 3000

app.listen(Port, ()=> console.log("Server started"))