const mongoose = require('mongoose');

const user = new mongoose.Schema({
    
    id:{
        type:Number
    },
    firstName:{
        type:String
    },
    lastName:{
        type:String
    }
    
});

const User = mongoose.model('User', user)

module.exports = User

//module.exports = User = mongoose.model('user', user)