const express = require ('express');
const mongoose = require('mongoose')
const User = require('../DB/User')
const route = express.Router();
const records = mongoose.model('User')

// below method need to provide data in json format via postman(in body), example below
// {
// 	"firstName":"shubham",
// 	"lastName":"zurange"
// }	

route.post('/insertrec', async (req, res) => {
    const { id, firstName, lastName } = req.body;
    let user = {};
    user.id = id;
    user.firstName = firstName;
    user.lastName = lastName;
    let userModel = new User(user);
    await userModel.save();
    res.json(userModel);
});







//below method is for passing hardcoded value.

// route.post('/insert', async (req, res) => {
    
//     let user = new User({
//         id : 1,
//         firstName : "ram",
//         lastName : "verma"
//     })
//     let result = await user.save();
//     res.json(result);
// });


route.get('/listall', (req, res) => {
    records.find((err, docs) => {
        if (!err) {
            res.send(
                docs
            );
        }
        else {
            console.log('Error in retrieving employee list :' + err);
        }
    });
});



// route.get('/listone', (req, res) => {
//     //records.findOne({_id:"5ecc574e9462de1638314a9b"}, (err, document)=>     ( here _id is the key of record in MongoDB database)
//     records.findOne({id:"5"}, (err, document)=>      
//     {
//         if (!err) {
//             res.send(document);         
//             //res.send(document.firstName);       
//                                  //here you can also display specific entity from the records, eg. (document.firstName), lastName, id,....anything 
//         }
//         else {
//             console.log('Error in retrieving employee list :' + err);
//         }
//     })
// });


//below method is use to retrieve the records and show only specifc fields ( ex - records showing firstName only, records showing lastName only)
// _id of the records displayed by default with every record

// route.get('/listspecific', (req, res) => {
  
//     records.find({}, 'firstName', function (err, rec) {
//       if(err) 
//       {
//           res.send("Error" +err);
//       }
//       else
//       { 
//       res.send(rec)
//       }
//     });
//     });
    



//below method is use to delete user by passing  ( id, _id, firstName, LastName) in the url
//in the postman it dosent give output but the user get deleted from mongo atlas database 
//in postman pass ( '/del/:id' = /del/sagar  (sagar = ':id' which is record name to delete))

route.delete('/del/:id', (req, res) => {
  
records.findOneAndDelete({id:req.params.id}, function (err, rec) {
  if(err) 
  {
      res.send("Error" +err);
      res.json(err)
  }
  else
  { 
  console.log("Successful deletion");
  res.send(rec)
  }
});
});

//below method is used to update any record from the database
//we are passing the id of the record of which we have to update certain field value
//then after findind record of that id, we are changing its firstname and lastname
//in postman pass ( '/change/:id' = /change/4  (4 = ':id')  and set it to put


route.post('/change/:id', (req, res) =>{ 
    const { id, firstName, lastName } = req.body;
    
    records.findOneAndUpdate({id:req.params.id},{$set:{firstName:firstName, lastName:lastName}}, function (err, rec) {
      if(err) 
      {
          res.send("Error" +err);
      }
      else
      { 
      console.log("records updated")
      console.log(rec)
      }
    });
    });


    






// route.delete('/delfield/:id', (req, res) => {
  
    //     records.update({id:req.params.id},{$unset:{firstName:"",lastName:""}}, function (err, rec) {
    //       if(err) 
    //       {
    //           res.send("Error" +err);
    //       }
    //       else
    //       { 
    //       console.log("records updated")
    //       }
    //     });
    //     });
    
    






    module.exports = route;